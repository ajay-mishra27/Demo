create table dbo.t_process_message_dump (
    id int NOT NULL,
    message nvarchar(max),
    process_status varchar(255), // success or failure.
    error_message varchar(max), // error message if failure.
    created_at DATETIME DEFAULT GETDATE(),
    pipeline_config_id varchar(255),
);