CREATE TABLE [dbo].[T_PaymentStatusHistory](
[PaymentStatusHistory_RowID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
[Payment_RowID] [int] NOT NULL,
[PaymentStatusID] [int] NOT NULL, 
[StatusDateTime] [datetime] NOT NULL, 
[Createdby] [varchar](255) NULL, 
[CreatedDateTime] [datetime] NULL, 
[Modifiedby] [varchar](255) NULL, 
[ModifiedDateTime] [datetime] NULL)

-- CONSTRAINT [PK_PaymentStatusHistory] PRIMARY KEY CLUSTERED