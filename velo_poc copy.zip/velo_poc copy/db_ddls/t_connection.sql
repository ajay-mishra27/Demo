create table dbo.t_connection (
    id int NOT NULL IDENTITY(1,1),
    connection_name nvarchar(max),
    json_message nvarchar(max),
    created_at DATETIME DEFAULT GETDATE()
);