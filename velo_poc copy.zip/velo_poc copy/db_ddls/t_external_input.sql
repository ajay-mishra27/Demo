create table dbo.t_external_input_dump (
    id int NOT NULL IDENTITY(1,1) ,
    message nvarchar(max),
    created_at DATETIME DEFAULT GETDATE(),
    table_name varchar(255),
    is_processed varchar(10)
);