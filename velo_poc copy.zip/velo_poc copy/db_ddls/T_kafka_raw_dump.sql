create table dbo.t_kafka_raw_dump (
    id int NOT NULL IDENTITY(1,1) ,
    message nvarchar(max),
    created_at DATETIME DEFAULT GETDATE(),
    pipeline_config_id varchar(10),
    file_name varchar(255),
);