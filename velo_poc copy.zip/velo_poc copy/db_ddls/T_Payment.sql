CREATE TABLE [dbo].[T_Payment](
[Payment_RowID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
[PaymentPlatformReferenceNumber] [varchar](16) NOT NULL,
[PaymentTypeID] [int] NOT NULL, 
[PaymentStatusID] [int] NOT NULL, 
[APIConsumerID] [int] NOT NULL,
[APIConsumerChannelID] [int] NOT NULL,
[IsDuplicate] [bit] NULL,
[ErrorCode] [varchar](255) NULL,
[ErrorReason] [varchar](255) NULL,
[ProcessingSystemReferenceNumber_ACK] [varchar](255) NULL,
[ProcessingSystemReferenceNumber_Result] [varchar](255) NULL,
[ACHBatchFilename] [varchar](50) NULL,
[ACHBulkRequestID] [int] NULL,
[ReceivedDateTime] [datetime] NOT NULL, 
[QueuedDateTime] [datetime] NOT NULL, 
[PickedDateTime] [datetime] NULL, 
[SentDateTime] [datetime] NULL,
[PaymentACKDateTime] [datetime] NULL,
[PaymentResultDateTime] [datetime] NULL,
[StatusDateTime] [datetime] NULL, 
[CancelledBy] [varchar](255) NULL,
[CancelledDateTime] [datetime] NULL, 
[PaymentRequest] [nvarchar](max) NULL,
[CreatedBy] [varchar](255) NULL,
[CreatedDateTime] [datetime] NULL, 
[ModifiedBy] [varchar](255) NULL,
[ModifiedDateTime] [datetime] NULL
)

-- CONSTRAINT [PK_Payments] PRIMARY KEY CLUSTERED
-- (
-- [Payment_RowID] ASC
-- )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY],
-- CONSTRAINT [UQ_PaymentPlatform_Refnum] UNIQUE NONCLUSTERED


