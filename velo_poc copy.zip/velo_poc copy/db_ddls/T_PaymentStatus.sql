CREATE TABLE [dbo].[T_PaymentStatus_Lookup](
[PaymentStatusID] [int] IDENTITY(1,1) NOT NULL,
[PaymentStatusDescription] [varchar](255) NOT NULL,
[PaymentTypeID] [int] NOT NULL,
[CustomerStatusID] [int] NOT NULL,
[StatusSequenceNumber] [int] NULL,
[Createdby] [varchar](255) NOT NULL,
[Createddatetime] [datetime] NOT NULL,
[Modifiedby] [varchar](255) NULL,
[Modifieddatetime] [datetime] NULL)