create table dbo.t_pipeline_config (
    pipeline_config_id int NOT NULL IDENTITY(1,1) ,
    pipeline_name varchar(50) NOT NULL,
    json_message nvarchar(max),
    created_by varchar,
    created_at DATETIME DEFAULT GETDATE(),
    updated_by varchar,
    updated_at DATETIME DEFAULT GETDATE()
);
