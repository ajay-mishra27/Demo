### VELO POC application.

### To start the app use.##For Local
```
docker compose up --build
```

### To build / run on server
```
   sudo docker build -t poc .
   docker run -p 8000:8000 -d poc
```

### Docker Kafka server
```
cd kafka
docker-compose up -d
```

### Create local mssql DB instance
```
docker run -e "ACCEPT_EULA=Y" -e "MSSQL_SA_PASSWORD=velo23_Password" \
   -p 1433:1433 --name sql1 --hostname sql1 \
   -d \
   mcr.microsoft.com/mssql/server:2022-latest
```

### Kafka Listener
```
./kafka-console-consumer.sh --topic paymentsmock2 --from-beginning --bootstrap-server ec2-100-26-170-196.compute-1.amazonaws.com:9092
```

### Requirements for the csv file
1. File must have header in it

