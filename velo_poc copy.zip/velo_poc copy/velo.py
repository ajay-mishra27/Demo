from flask import Flask
# import schedule
from apscheduler.schedulers.background import BackgroundScheduler
import time
from app import support
from app import pipeline
from app import connection
from flask import request
import json
from flask_cors import CORS


scheduler = BackgroundScheduler()
scheduler.add_job(support.job, trigger="interval", seconds=60)
scheduler.add_job(support.job_db_table, trigger="interval", seconds=60)
# scheduler.add_job(support.job_kafka, trigger="interval", seconds=60)
scheduler.start()
# schedule.every(1).minutes.do(support.job)

app = Flask(__name__)
CORS(app, support_credentials=True) 

@app.route("/")
def hello_world():
    return "Hello", 200

@app.route("/pipelines", methods=['GET'])
def get_pipelines():
    args = request.args
    params = dict(request.args)
    return pipeline.get_pipelines(params), 200, {'Content-Type': 'application/json'}    

@app.route("/pipelines", methods=['POST'])
def pipelines():
    args = request.args
    params = dict(request.args)
    # print(params)
    message = {}
    if params == {}:
        get_id = pipeline.save_config(request.json)
        message["id"] = get_id
        message["message"] = "Config saved successfully"
    else:   
        pipeline.update_config(request.json, params['id'])
        message["message"] = "Config updated successfully"
    return message, 200, {'Content-Type': 'application/json'}    

@app.route("/pipelines", methods=['DELETE'])
def delete_pipelines():
    args = request.args
    params = dict(request.args)
    pipeline.delete_pipeline(params['id'])
    return "Pipeline deleted successfully", 200, {'Content-Type': 'application/json'}

@app.route("/get_data", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return "No file uploaded", 400
    file = request.files["file"]
    if file.filename == "":
        return "No file selected", 400
    args = request.args
    params = dict(request.args)
    file_name = file.filename
    file_content = file.stream.read().decode("utf-8")
    first_line = support.get_first_line_from_file(file_content, params, file_name)
    return first_line, 200, {'Content-Type': 'application/json'}


@app.route('/simulate_run', methods=['POST'])
def simulate_run():
    args = request.args
    params = dict(request.args)
    processed_data_row_id = support.simulate_run(params['pipeline_id'])
    response_message = {}
    response_message['message'] = "Simulation run successfully"
    response_message['rows'] = []
    for row in processed_data_row_id:
        processed_data = support.get_processed_data_by_id(row)
        data={}
        for row_1 in processed_data:
            data['id'] = row
            data['message_variant'] = row_1[1]
            try:
                data['message']=json.loads(row_1[0])
            except json.JSONDecodeError as e:
                print(f"Error converting to JSON: {e}")
                data['message']=row_1[0]
            response_message['rows'].append(data)
    return response_message, 200, {'Content-Type': 'application/json'}

@app.route("/raw_data", methods=["GET"])
def get_raw_id():
    args = request.args
    params = dict(request.args)
    if 'id' in params:
        raw_data = support.get_raw_data_by_id(params['id'])
    elif 'pipeline_id' in params:
        raw_data = support.get_raw_data_by_pipline(params['pipeline_id'])

    return raw_data, 200, {'Content-Type': 'application/json'}

@app.route("/process_data", methods=["GET"])
def get_processed_data():
    args = request.args
    params = dict(request.args)
    processed_data = support.get_processed_data_by_id(params['id'])
    data={}
    for row_1 in processed_data:
        data['message_variant'] = row_1[1]
        data['message'] = (json.loads(row_1[0]))        
    return data, 200, {'Content-Type': 'application/json'}

@app.route("/process_data", methods=["POST"])
def process_data():
    filename = "api_processed_data"
    args = request.args
    params = dict(request.args)
    # assuming this data same as CSV and so pipline is 1
    pipline_config = int(params['pipline_id'])
    row_id = support.process_line_data(json.dumps(request.json), filename, pipline_config)
    return f"Data Processed Ref. id: {row_id}", 200, {'Content-Type': 'application/json'}

@app.route("/admin/connection", methods=["POST", "PATCH"])
def post_connection():
    args = request.args
    params = dict(request.args)
    message = {}
    if params == {}:
        connection.create_connection(request.json)
        message["Connection_ID"] = connection.get_connection_id(request.json)
        message["Message"] = "Connection data saved"
        return message, 200, {'Content-Type': 'application/json'}
    else:
        connection.update_connection(request.json, params['id'])
        message["Connection ID"] = connection.get_connection_id(request.json)
        message["Message"] = "Connection data updated"
        return message, 200, {'Content-Type': 'application/json'}

@app.route("/admin/connection", methods=["GET"])
def get_connection():
    args = request.args
    params = dict(request.args)
    return connection.get_connection(params), 200, {'Content-Type': 'application/json'}

@app.route("/admin/connection", methods=["DELETE"])
def delete_connection():
    args = request.args
    params = dict(request.args)
    connection.delete_connection(params)
    message = {}
    message["Connection ID"] = params['id']
    message["Message"] = "Connection data deleted"
    return message, 200, {'Content-Type': 'application/json'}
    
