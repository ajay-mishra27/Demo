from app import support
import json

def save_config(request):
    json_string = json.dumps(request)
    query = f"insert into dbo.t_pipeline_config (pipeline_name, json_message, created_by, updated_by) values ('{request['pipelineName']}','{json_string}','1','1');"
    get_id = support.execute_query(query)
    return str(get_id[0])

def update_config(request, id):
    json_string = json.dumps(request)
    query = f"update dbo.t_pipeline_config set pipeline_name='{request['pipelineName']}', json_message='{json_string}', updated_by='1' where pipeline_config_id={id};"
    support.execute_query(query)

def delete_pipeline(id):
    query = f"delete from dbo.t_pipeline_config where pipeline_config_id={id};"
    support.execute_query(query)

def get_pipelines(params):
    if params == {}:
        query = "select pipeline_config_id, pipeline_name, created_at, updated_at from dbo.t_pipeline_config;"
    else:
        query = f"select pipeline_config_id, pipeline_name, created_at, updated_at, json_message from dbo.t_pipeline_config where pipeline_config_id={params['id']};"
    rows = support.execute_query(query)
    pipelines = []
    for row in rows:
        pipeline = {}
        pipeline["id"] = row[0]
        pipeline["name"] = row[1]
        pipeline["createdAt"] = str(row[2])
        pipeline["updatedAt"] = str(row[3])
        if len(row) > 4:
            pipeline["config"] = json.loads(row[4]) 
        pipelines.append(pipeline)

    return json.dumps(pipelines)
