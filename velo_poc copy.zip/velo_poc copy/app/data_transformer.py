import sys
from app.data_enrichment_service import DataEnrichment  
from app import support
import pyodbc 
import json
import copy

def transform_enhance_data(row_id, simulation=False):
    print("File enrichment started")
    try:
        print("File transaformation started")
        process = DataEnrichment()
        cursor, conn = support.get_db_cursor()
        
        try:
            cursor.execute(f"""
                            SELECT [pipeline_config_id]
        ,[pipeline_name]
        ,[json_message]
        ,[created_by]
        ,[created_at]
        ,[updated_by]
        ,[updated_at]
    FROM [paymentProcessing].[dbo].[t_pipeline_config] 
    where pipeline_config_id=(select pipeline_config_id from paymentProcessing.dbo.t_kafka_raw_dump tkrd where id={row_id})
            """)
            columns = [column[0] for column in cursor.description]
            result = cursor.fetchall()
            cursor.execute(f"""
                                    SELECT [id]
                        ,[message]
                        ,[created_at]
                        ,[pipeline_config_id]
                        ,[file_name]
                    FROM [paymentProcessing].[dbo].[t_kafka_raw_dump]
                    where id={row_id}
            """)
            columns1 = [column[0] for column in cursor.description]
            result1 = cursor.fetchall()
        finally:
            support.close_db_connection(cursor, conn)
        input_json = []
        results=[]
        dataframes = []
        dataframe = []
        json_arryay_enrich = []
        json_arryay_transfarmeres = []
        dump_row_id = []
        for row in result:
            results.append(dict(zip(columns, row)))
        for row in result1:
            dataframe.append(dict(zip(columns1, row)))
        for row in results:
            input_json.append(json.loads(row['json_message']))
        for row in dataframe:
            dataframes.append(json.loads(row['message']))
        for each_json in input_json:
            project_name = each_json["pipelineName"]
            print(each_json["pipelineName"])
            configuration_json = each_json['configuration']
            for each_config_json in configuration_json:
                #message_variants_json = each_config_json['source_kde'][0]['Message_variants']
                source_kdes_json = each_config_json['source_kde']
                for source_kdes_each_json in source_kdes_json:
                    source_kds_rows = source_kdes_each_json['rows']
                    message_variants_json = source_kdes_each_json['Message_variants']
                    for message_variants_each_json in message_variants_json:
                        dataframes_new = copy.deepcopy(dataframes)
                        #dataframes_new = dataframes.copy()
                        message_variant_name = message_variants_each_json["variant_name"]
                        pipeline_operators = message_variants_each_json['pipeline_operators']
                        target_kdes = message_variants_each_json['target_kdes'][0]['rows']
                        for pipeline_operators_json in pipeline_operators:
                            if pipeline_operators_json.get('enricher'):
                                for each_json in pipeline_operators_json['enricher']['rows']:
                                    json_arryay_enrich.append(each_json)
                            if pipeline_operators_json.get('transformer'):
                                for each_json in pipeline_operators_json['transformer']['rows']:
                                    json_arryay_transfarmeres.append(each_json)
                        # print(dataframes_new)
                        # print(json_arryay_enrich)
                        index = 0
                        fianl_array = []
                        for each_frame in dataframes_new:
                            print(f"Strted for the data enrichment for row {index}")
                            kde_json = {}
                            for each_kde in source_kds_rows:
                                if each_kde['element_tag'] in each_frame:
                                    kde_json[each_kde['element_tag_name']] = each_frame[each_kde['element_tag']]
                                else:
                                    kde_json[each_kde['element_tag_name']] = ""
                            final_json = process.perform_data_enrich(each_frame,json_arryay_enrich)
                            final_tran = process.perform_data_trans(each_frame,json_arryay_transfarmeres,kde_json)
                            merged_dict = {**kde_json,**final_json, **final_tran}
                            final_string = ""
                            for eachJson in target_kdes:
                                final_string = final_string + eachJson['element_tag_name']
                                val = ""
                                if eachJson['element_tag_value'] in merged_dict:
                                    val =  merged_dict[ eachJson['element_tag_value']]
                                else:
                                    val =  eachJson['element_tag_value']
                                if val == "":
                                    final_string = final_string + str(val)
                                elif val.isdigit():
                                    final_string = final_string + str(int(val))
                                else:
                                    final_string = final_string + "\""+str(val).strip()+"\""
                            index = index + 1
                           
                        try:
                            # Try to convert the data to JSON
                            final_json = json.loads(final_string)
                        except json.JSONDecodeError as e:
                            # If conversion fails, handle the exception
                            print(f"Error converting to JSON: {e}")
                            # Pass the original data back as a string
                            json_data = str(final_string)
                        fianl_array.append(final_string)
                            #final_json = json.loads(final_string)
                            #fianl_array.append(final_string)
                        print("After enrichment and Transfer")
                        for eachJson in fianl_array:
                            query = f'insert into dbo.t_process_message_dump (id, variant_name,message, process_status, pipeline_config_id) values (\'{row_id}\',\'{message_variant_name}\',\'{eachJson}\',\'success\',\'{result[0][0]}\');'
                            dump_row_id.append(support.execute_query(query)[0])
                        # Generating File for output to S3
                        # target_kdes_json =  message_variants_each_json['target_kdes']
                        # file_name = f'{project_name}_{message_variant_name}.json' 
                        # with open("file_name",'w') as file:
                        #     json.dump(dataframes,file,ensure_ascii=False)
                        print(f"File Transformation Ended {dump_row_id}")  
                        json_arryay_enrich = [] 
                        json_arryay_transfarmeres = []
        return(dump_row_id)
    except Exception as exp:
        print("Excetion")
        #print(exp.message)
        raise(exp)