from app import support
import json

def create_connection(request):
    connection_name = request['conn_name']
    json_string = json.dumps(request)
    query = f"insert into dbo.t_connection (connection_name,json_message) values ('{connection_name}','{json_string}');"
    support.execute_query(query)

def update_connection(request, id):
    json_string = json.dumps(request)
    query = f"update dbo.t_connection set json_message = '{json_string}' where id = {id};"
    support.execute_query(query)

def get_connection_id(request):
    json_string = json.dumps(request)
    query = f"select id from dbo.t_connection where json_message = '{json_string}';"
    rows = support.execute_query(query)
    for row in rows:
        return row[0]

def get_connection(params):
    if params == {}:
        query = f"select id, connection_name, created_at from dbo.t_connection;"
    else:
        query = f"select id, connection_name, created_at, json_message from dbo.t_connection where id = {params['id']};"
    rows = support.execute_query(query)
    party = []
    for row in rows:
        pipeline = {}
        pipeline["id"]  = row[0]
        if len(row) < 4:
            pipeline["conn_name"] = row[1]
        pipeline["createdAt"] = str(row[2])
        if len(row) > 3:
            pipeline_2 = json.loads(row[3])
            pipeline.update(pipeline_2)
        party.append(pipeline)
    return json.dumps(party)

def delete_connection(params):
    query = f"delete from dbo.t_connection where id={params['id']};"
    support.execute_query(query)