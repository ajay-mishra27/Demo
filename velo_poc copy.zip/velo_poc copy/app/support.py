# Run below method every 2 mins
import time
import json
import boto3
from kafka import KafkaProducer
import pyodbc 
from datetime import datetime
import os
import csv
import pandas as pd
# import xml.etree.ElementTree as ET
import xmltodict
import io
from app import data_transformer

# parse app_creds.json file
with open('app_creds.json') as f:
    data = json.load(f)
    bucket_name = data['aws_s3_bucket_name']
    aws_access_key_id = data['aws_access_key_id']
    aws_secret_access_key = data['aws_secret_access_key']
    server = data['aws_rds_db_server']
    username = data['aws_rds_db_user']
    password = data['aws_rds_db_pass']
    database_name = data['aws_rds_db_name']
    kafka_bootstrap_server = data['kafka_bootstrap_server']
    kafka_topic = data['kafka_topic']

def get_db_cursor():        
    cnxn = pyodbc.connect("Driver={ODBC Driver 18 for SQL Server};"
                            "Server="+server+",1433;"
                            "Database="+database_name+";"
                            "UID="+username+";PWD="+password+";"
                            "Trusted_Connection=no;TrustServerCertificate=yes;")

    cursor = cnxn.cursor()
    return cursor, cnxn

def close_db_connection(cursor, cnxn):
    cursor.close()
    cnxn.close()

def flatten_json_data(y):
    out = {}
    def flatten(x, name=''):
        if type(x) is dict:
            for a in x:
                flatten(x[a], name + a + '_$_')
        elif type(x) is list:
            i = 0
            for a in x:
                flatten(a, name + str(i) + '_$_')
                i += 1
        else:
            out[name[:-1]] = x
    flatten(y)
    return out

def write_to_kafka(message):
    # create instance for producing messages
    producer = KafkaProducer(bootstrap_servers=[kafka_bootstrap_server])
    # send the message to the topic
    producer.send(kafka_topic, message.encode('utf-8'))
    # flush the producer
    producer.flush()
    # close the producer
    producer.close()

def execute_query(query):
    cursor, cnxn = get_db_cursor()
    if query.startswith("select"):
        cursor.execute(query)
        rows = cursor.fetchall()
    else:
        rows = []
        cursor.execute(query)
        # Get the id of the executed insert query
        new_id_query = "SELECT SCOPE_IDENTITY();"
        cursor.execute(new_id_query)
        row_id = cursor.fetchone()[0]
        rows.append(str(row_id))
        cursor.execute("Commit;")
    close_db_connection(cursor, cnxn)
    return rows

# def transform_enhance_data(row_id, simulation=False):
#     # Call transformation / enhancement code here
#     if simulation:
#         print("Simulation for Transformation / Enhancement code here")
#         print(row_id)
#         processed_data_row_id = row_id
#         return processed_data_row_id
#     else:
#         print("Executing Transformation / Enhancement code here")
#         print(row_id)

def process_line_data(line, file_name, config_id):
    write_to_kafka(line)
    query = f'insert into dbo.t_kafka_raw_dump (message, file_name, pipeline_config_id) values (\'{line}\', \'{file_name}\',\'{config_id}\');'
    row_id = execute_query(query)
    data_transformer.transform_enhance_data(row_id[0], False)
    return row_id[0]

def get_pipline_config():
    # todo - fix the query to get the pipline with name for file/topic 
    query = "select * from dbo.t_pipeline_config"
    rows = execute_query(query)
    pipline_config = {}
    for row in rows:
        rows_j = json.loads(row[2])
        if rows_j['configuration'][0]['source_config']['type'] in pipline_config:
            continue
        pipline_config[rows_j['configuration'][0]['source_config']['type']] = str(row[0])
    return pipline_config

def simulate_run(pipline_id):
    file_name_query = f"select TOP 1 file_name from dbo.t_kafka_raw_dump where pipeline_config_id ={pipline_id} and file_name like 'UI Sample Parser%' order by created_at desc"
    row_id = execute_query(file_name_query)
    file_name = row_id[0][0]
    row_id_query = f"select TOP 100 id from dbo.t_kafka_raw_dump where pipeline_config_id={pipline_id} and file_name='{file_name}'"
    row_id = execute_query(row_id_query)
    processed_data_row_id = []
    for row in row_id:
        processed_data_row_id = processed_data_row_id + (data_transformer.transform_enhance_data(row[0], True))
    return processed_data_row_id

def get_first_line_from_file(file_data, params, file_name_org):    
    row_value = []
    currentDateAndTime = datetime.now()
    currentTime = currentDateAndTime.strftime("-%Y%m%d-%H%M%S")    
    file_name = f"UI Sample Parser {currentTime}"
    config_id = params['pipline_id']    
    if '.xml' in file_name_org:
        xml_string = io.StringIO(file_data)
        json_data = xmltodict.parse(xml_string.getvalue()) 
        if json_data.get('root', {}).get('document', []):
            documents = json_data.get('root', {}).get('document', [])
            for document in documents:
                row = flatten_json_data(document)
                query = f'insert into dbo.t_kafka_raw_dump (message, file_name, pipeline_config_id) values (\'{json.dumps(row)}\', \'{file_name}\',\'{config_id}\');'
                tmp_hash = {}
                row_id = execute_query(query)
                tmp_hash[row_id[0]] = row
                row_value.append(tmp_hash)
        else:
            row = flatten_json_data(json_data)
            query = f'insert into dbo.t_kafka_raw_dump (message, file_name, pipeline_config_id) values (\'{json.dumps(row)}\', \'{file_name}\',\'{config_id}\');'
            tmp_hash = {}
            row_id = execute_query(query)
            tmp_hash[row_id[0]] = row
            row_value.append(tmp_hash)
        return row_value        
    elif '.csv' in file_name_org:
        df = pd.read_csv(io.StringIO(file_data))
        for row in df.to_dict(orient='records'):
            tmp_hash = {}            
            query = f'insert into dbo.t_kafka_raw_dump (message, file_name, pipeline_config_id) values (\'{json.dumps(row)}\', \'{file_name}\',\'{config_id}\');'
            row_id = execute_query(query)
            tmp_hash[row_id[0]] = row
            row_value.append(tmp_hash)
        return row_value
    else:
        print('format not supported')
    return row_value

def job():
    print(time.ctime() + " - Processing files from S3 bucket")

    # Fetch files from a folder on AWS s3 bucket:
    s3 = boto3.resource('s3',
                        aws_access_key_id=aws_access_key_id,
                        aws_secret_access_key=aws_secret_access_key
                        )

    currentDateAndTime = datetime.now()
    currentTime = currentDateAndTime.strftime("-%Y%m%d-%H%M%S")
    bucket = s3.Bucket(bucket_name)
    for obj in bucket.objects.all():
        # if obj.key.startswith('incoming-test/'):
        if obj.key.startswith('incoming/'):
            file_name = os.path.basename(obj.key) 
            filename = file_name + currentTime
            if file_name == '':
                continue            
            pipline_config = get_pipline_config()
            if obj.key.endswith('.txt'):
                file_content=obj.get()['Body'].read().decode('utf-8')
                lines = file_content.split('\n')
                for line in lines:
                    if line.strip():
                        process_line_data(line, filename, pipline_config['file'])
                s3.meta.client.copy({'Bucket': bucket_name, 'Key': obj.key}, bucket_name, 'archive/'+filename)
                obj.delete()
            elif obj.key.endswith('.csv'):
                # Todo: Exception handling needs testing
                try:
                    df = pd.read_csv(obj.get()['Body'])
                    for row in df.to_dict(orient='records'):
                        process_line_data(json.dumps(row), filename, pipline_config['file'])
                    s3.meta.client.copy({'Bucket': bucket_name, 'Key': obj.key}, bucket_name, 'archive/'+filename)
                    obj.delete()   
                except pd.errors.EmptyDataError:
                    print('No data.')
                except pd.errors.ParserError:
                    print('Parse error.')
                except Exception:
                    print('Exception :' + Exception.message)
            elif obj.key.endswith('.xml'):            
                try:
                    xml_string = obj.get()['Body'].read().decode('utf-8')
                    json_data = xmltodict.parse(xml_string) 
                    flattern = flatten_json_data(json_data)
                    # To avoid using pipline_config as 4 for xml for now..                    
                    process_line_data(json.dumps(flattern), filename, '4')
                    # process_line_data(json.dumps(json_data), filename, pipline_config['file'])
                    s3.meta.client.copy({'Bucket': bucket_name, 'Key': obj.key}, bucket_name, 'archive/'+filename)
                    obj.delete()                       
                except Exception:
                    print('Exception : ' + Exception.message)                    
            else:
                if obj.key != 'incoming/':
                    s3.meta.client.copy({'Bucket': bucket_name, 'Key': obj.key}, bucket_name, 'exception/'+filename)
                    obj.delete()

def job_db_table():
    print(time.ctime() + " - Processing data from Input Table")
    pipline_config = get_pipline_config()
    query = f"select message from dbo.t_external_input_dump where is_processed is NULL"
    rows = execute_query(query)
    processed_data_row_id = []
    for row in rows:
        process_line_data(row[0], 'db_table_t_external_input_dump', '3')
        query = f"update dbo.t_external_input_dump set is_processed = 'True' where message = '{row[0]}'"
        execute_query(query)
    return processed_data_row_id

def get_raw_data_by_id(params_id):
    query = f"select message from dbo.t_kafka_raw_dump where id={params_id}"
    rows = execute_query(query)
    return rows[0][0]

def get_raw_data_by_pipline(params_id):
    file_name_query = f"select TOP 1 file_name from dbo.t_kafka_raw_dump where pipeline_config_id ={params_id} and file_name like 'UI Sample Parser%' order by created_at desc"
    row_id = execute_query(file_name_query)
    file_name = row_id[0][0]
    rows_query = f"select * from dbo.t_kafka_raw_dump where pipeline_config_id={params_id} and file_name='{file_name}'"
    rows = execute_query(rows_query)
    row_value = []
    for row in rows:
        tmp_hash = {}
        tmp_hash[row[0]] = json.loads(row[1])
        row_value.append(tmp_hash)
    return row_value

def get_processed_data_by_id(params_id):
    query = f"select message, variant_name from dbo.t_process_message_dump where uni_id={params_id}"
    rows = execute_query(query)
    if rows == []:
        return "No data found"
    else:
        return rows

